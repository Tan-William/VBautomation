This sample database contains two forms that demonstrate
how "multi-value" data can be easily maintained in versions
of ACCESS prior to 2007 version. (ACCESS 2007 allows you to
use a "multi-value" field, and it has its own, unique control
that allows you to select various values for the field.)

("Multi-value" data represent the data that are in a
"junction" table, where "Many-to-Many" data relationships
are represented in a database.)

The form "frmPeople" (which opens automatically when you 
open the .mdb file) demonstrates the use of a listbox to
show the "junction" table's data. On this form, two 
listboxes are shown, one for each of the "multi-value" 
attributes that can be assigned to a person in the database. 
The buttons on the right side of the listbox are used to 
remove ("delete" icon on button) or add ("insert" icon on 
button) values. When you click on the add button, a 
combobox is displayed that allows you to select other 
possible values that already exist in the database as 
valid values for Hobbies or Clubs. 

The form "frmClubs" is a similar demonstration, except it
shows that only one attribute. As in the other form, the 
buttons on the right side of the listbox are used to remove 
("delete" icon on button) or add ("insert" icon on button) 
values. When you click on the add button, a combobox is 
displayed that allows you to select other possible values 
that already exist in the database as valid values for 
Hobbies or Clubs. 

The operation of these forms is handled by the use of a 
class module "MtoMListHandler". This class module controls
the listbox(es), add and remove buttons, and combobox(es).
(This setup is known as "subclassing" the controls, allowing
a "new" object class to control the behavior of multiple
controls on the form without having to write complex code.)
When you open either form in design view and look at the 
VBA code in the form's module, you'll see that the code 
is very simple: 
  a) The class object is instantiated.
  b) The various controls are passed to the class module 
	so that it can control them.
  c) The table and field names are passed to the class
	module so that it can create the appropriate
	RowSource properties and so that it can create
	and run SQL statements to add and remove data
	from the "junction" table.
Normally, the toggling of the combobox's visibility,
especially to make it invisible when it loses the focus,
is difficult to achieve because one cannot make a control
invisible until it no longer has the focus, but the 
LostFocus event occurs before the focus has been completely
lost. Therefore, this solution masks the combobox (makes it
"invisible") by covering it with a masking rectangle 
(also controlled by the class module) when focus is moving
to another control.

By using a class module, duplicative and repetitive VBA
code is eliminated from the form's module. Also, you can
have as many "listbox/combobox" combinations on a form as
you wish; you simply create a new instance of the class 
object for each combination (see "frmPeople" as an example
of this).
